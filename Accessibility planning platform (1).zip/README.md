
  # Accessibility planning platform

  This is a code bundle for Accessibility planning platform. The original project is available at https://www.figma.com/design/f7XJ9ugKoZP2eovD9K5AIH/Accessibility-planning-platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
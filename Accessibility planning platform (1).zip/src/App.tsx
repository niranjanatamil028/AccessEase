import { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { VenueCard } from './components/VenueCard';
import { VenueDetail } from './components/VenueDetail';
import { venues } from './data/venues';
import { Venue, FilterCategory } from './types/venue';
import { Alert, AlertDescription } from './components/ui/alert';
import { Toaster } from './components/ui/sonner';
import { Info } from 'lucide-react';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<FilterCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);

  const filteredVenues = useMemo(() => {
    return venues.filter(venue => {
      const matchesCategory = selectedCategory === 'all' || venue.category === selectedCategory;
      const matchesSearch = 
        venue.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        venue.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
        venue.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  if (selectedVenue) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <VenueDetail 
            venue={selectedVenue} 
            onBack={() => setSelectedVenue(null)} 
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <h1>Discover Accessible Venues</h1>
            <p className="text-muted-foreground">
              Find places with accessible seating, wheelchair access, and companion facilities
            </p>
          </div>

          <Alert>
            <Info className="size-4" />
            <AlertDescription>
              All venues show real-time accessible seat availability. Book in advance to ensure your preferred accessible seating.
            </AlertDescription>
          </Alert>

          <FilterBar
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            totalResults={filteredVenues.length}
          />

          {filteredVenues.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No venues found matching your criteria. Try adjusting your filters.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVenues.map(venue => (
                <VenueCard
                  key={venue.id}
                  venue={venue}
                  onClick={() => setSelectedVenue(venue)}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <footer className="border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>AccessEase - Making activities accessible for everyone</p>
            <p className="mt-2">© 2026 AccessEase. All rights reserved.</p>
          </div>
        </div>
      </footer>
      <Toaster />
    </div>
  );
}
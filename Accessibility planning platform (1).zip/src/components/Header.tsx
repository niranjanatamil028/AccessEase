import { Heart, Bell, User, Menu } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function Header() {
  return (
    <header className="border-b bg-background sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-lg bg-primary flex items-center justify-center">
              <Heart className="size-6 text-primary-foreground fill-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl">AccessEase</h1>
              <p className="text-xs text-muted-foreground">Plan accessible activities</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="size-5" />
              <span className="absolute top-1.5 right-1.5 size-2 bg-red-500 rounded-full" />
            </Button>
            <Button variant="ghost" size="icon">
              <User className="size-5" />
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="size-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}

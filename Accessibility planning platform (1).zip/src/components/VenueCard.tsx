import { useState } from 'react';
import { Venue } from '../types/venue';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { BookingModal } from './BookingModal';
import { MapPin, Star, Accessibility, Users, Calendar } from 'lucide-react';

interface VenueCardProps {
  venue: Venue;
  onClick: () => void;
}

export function VenueCard({ venue, onClick }: VenueCardProps) {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const availabilityPercentage = (venue.accessibleSeatsAvailable / venue.totalAccessibleSeats) * 100;
  
  const getAvailabilityColor = () => {
    if (availabilityPercentage >= 50) return 'bg-green-500';
    if (availabilityPercentage >= 25) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getCategoryLabel = (category: string) => {
    return category.charAt(0).toUpperCase() + category.slice(1);
  };

  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden"
      onClick={onClick}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={venue.image} 
          alt={venue.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <Badge variant="secondary" className="bg-white/90 backdrop-blur">
            {getCategoryLabel(venue.category)}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <CardTitle className="flex items-start justify-between gap-2">
          <span>{venue.name}</span>
          <div className="flex items-center gap-1 text-sm text-muted-foreground shrink-0">
            <Star className="size-4 fill-yellow-400 stroke-yellow-400" />
            <span>{venue.accessibilityRating}</span>
          </div>
        </CardTitle>
        <CardDescription className="flex items-center gap-1">
          <MapPin className="size-3" />
          <span>{venue.address}</span>
          {venue.distance && <span className="ml-auto">• {venue.distance} km</span>}
        </CardDescription>
      </CardHeader>

      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm">
              <Accessibility className="size-4 text-muted-foreground" />
              <span>Accessible Seats</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">
                {venue.accessibleSeatsAvailable}/{venue.totalAccessibleSeats}
              </span>
              <div className={`size-2 rounded-full ${getAvailabilityColor()}`} />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {venue.features.slice(0, 3).filter(f => f.available).map(feature => (
              <Badge key={feature.id} variant="outline" className="text-xs">
                {feature.name}
              </Badge>
            ))}
            {venue.features.filter(f => f.available).length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{venue.features.filter(f => f.available).length - 3} more
              </Badge>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            <Button 
              size="sm" 
              className="flex-1 gap-1.5"
              onClick={(e) => {
                e.stopPropagation();
                setBookingModalOpen(true);
              }}
            >
              <Calendar className="size-3.5" />
              Book Now
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              className="flex-1"
              onClick={onClick}
            >
              View Details
            </Button>
          </div>
        </div>
      </CardContent>

      <BookingModal 
        open={bookingModalOpen} 
        onOpenChange={setBookingModalOpen}
        venue={venue}
      />
    </Card>
  );
}
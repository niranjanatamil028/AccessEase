import { FilterCategory } from '../types/venue';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Search, 
  Film, 
  Utensils, 
  Landmark, 
  Theater, 
  Trophy,
  LayoutGrid
} from 'lucide-react';

interface FilterBarProps {
  selectedCategory: FilterCategory;
  onCategoryChange: (category: FilterCategory) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  totalResults: number;
}

const categories: { value: FilterCategory; label: string; icon: typeof Film }[] = [
  { value: 'all', label: 'All Places', icon: LayoutGrid },
  { value: 'cinema', label: 'Cinemas', icon: Film },
  { value: 'restaurant', label: 'Restaurants', icon: Utensils },
  { value: 'museum', label: 'Museums', icon: Landmark },
  { value: 'theater', label: 'Theaters', icon: Theater },
  { value: 'stadium', label: 'Stadiums', icon: Trophy },
];

export function FilterBar({ 
  selectedCategory, 
  onCategoryChange, 
  searchQuery, 
  onSearchChange,
  totalResults 
}: FilterBarProps) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search venues by name or location..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {categories.map((category) => {
          const Icon = category.icon;
          const isSelected = selectedCategory === category.value;
          
          return (
            <Button
              key={category.value}
              variant={isSelected ? 'default' : 'outline'}
              size="sm"
              onClick={() => onCategoryChange(category.value)}
              className="gap-2 shrink-0"
            >
              <Icon className="size-4" />
              {category.label}
            </Button>
          );
        })}
      </div>

      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>{totalResults} accessible venues found</span>
        <Badge variant="outline">
          Updated 5 min ago
        </Badge>
      </div>
    </div>
  );
}

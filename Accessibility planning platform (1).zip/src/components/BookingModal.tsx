import { useState } from 'react';
import { Venue } from '../types/venue';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Calendar as CalendarIcon, Clock, Users, Accessibility, CheckCircle2, Phone, Mail } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface BookingModalProps {
  venue: Venue;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BookingModal({ venue, open, onOpenChange }: BookingModalProps) {
  const [step, setStep] = useState<'details' | 'confirmation'>('details');
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState<string>('');
  const [accessibleSeats, setAccessibleSeats] = useState(1);
  const [companionSeats, setCompanionSeats] = useState(0);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [specialRequirements, setSpecialRequirements] = useState<string[]>([]);

  const timeSlots = venue.category === 'cinema' 
    ? ['10:00 AM', '1:00 PM', '4:00 PM', '7:00 PM', '10:00 PM']
    : venue.category === 'restaurant'
    ? ['12:00 PM', '1:00 PM', '2:00 PM', '7:00 PM', '8:00 PM', '9:00 PM']
    : venue.category === 'stadium'
    ? ['3:00 PM', '6:00 PM']
    : ['10:00 AM', '3:00 PM', '6:00 PM'];

  const requirements = [
    { id: 'wheelchair-space', label: 'Wheelchair Space Required' },
    { id: 'assistance', label: 'Staff Assistance Needed' },
    { id: 'audio-description', label: 'Audio Description' },
    { id: 'sign-language', label: 'Sign Language Interpreter' },
    { id: 'service-animal', label: 'Bringing Service Animal' },
  ];

  const handleToggleRequirement = (id: string) => {
    setSpecialRequirements(prev =>
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const totalSeats = accessibleSeats + companionSeats;
  const pricePerSeat = venue.category === 'cinema' ? 250 : venue.category === 'restaurant' ? 500 : venue.category === 'stadium' ? 800 : 300;
  const totalPrice = totalSeats * pricePerSeat;

  const handleBooking = () => {
    if (!date || !time || !name || !email || !phone) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (accessibleSeats > venue.accessibleSeatsAvailable) {
      toast.error('Not enough accessible seats available');
      return;
    }

    setStep('confirmation');
  };

  const handleConfirmBooking = () => {
    toast.success('Booking confirmed! You will receive a confirmation email shortly.', {
      description: `Booking ID: BK${Date.now().toString().slice(-8)}`,
      duration: 5000,
    });
    
    // Reset form
    setStep('details');
    setDate(undefined);
    setTime('');
    setAccessibleSeats(1);
    setCompanionSeats(0);
    setName('');
    setEmail('');
    setPhone('');
    setSpecialRequirements([]);
    onOpenChange(false);
  };

  const handleBack = () => {
    setStep('details');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {step === 'details' ? (
          <>
            <DialogHeader>
              <DialogTitle>Book Accessible Seats</DialogTitle>
              <DialogDescription>
                Reserve your accessible seats at {venue.name}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Date Selection */}
              <div className="space-y-2">
                <Label htmlFor="date">Select Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 size-4" />
                      {date ? format(date, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Time Selection */}
              <div className="space-y-2">
                <Label htmlFor="time">Select Time Slot *</Label>
                <Select value={time} onValueChange={setTime}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((slot) => (
                      <SelectItem key={slot} value={slot}>
                        <div className="flex items-center gap-2">
                          <Clock className="size-4" />
                          {slot}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              {/* Seat Selection */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="accessible-seats">Accessible Seats *</Label>
                  <Select 
                    value={accessibleSeats.toString()} 
                    onValueChange={(val) => setAccessibleSeats(parseInt(val))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((num) => (
                        <SelectItem key={num} value={num.toString()} disabled={num > venue.accessibleSeatsAvailable}>
                          {num} {num === 1 ? 'seat' : 'seats'}
                          {num > venue.accessibleSeatsAvailable && ' (Unavailable)'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {venue.accessibleSeatsAvailable} available
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companion-seats">Companion Seats</Label>
                  <Select 
                    value={companionSeats.toString()} 
                    onValueChange={(val) => setCompanionSeats(parseInt(val))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[0, 1, 2, 3, 4].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} {num === 1 ? 'seat' : 'seats'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              {/* Contact Information */}
              <div className="space-y-4">
                <h4>Contact Information</h4>
                
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+91 XXXXX XXXXX"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Special Requirements */}
              <div className="space-y-3">
                <h4>Special Requirements</h4>
                <div className="space-y-3">
                  {requirements.map((req) => (
                    <div key={req.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={req.id}
                        checked={specialRequirements.includes(req.id)}
                        onCheckedChange={() => handleToggleRequirement(req.id)}
                      />
                      <label
                        htmlFor={req.id}
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {req.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Price Summary */}
              <div className="space-y-2 rounded-lg bg-muted p-4">
                <h4>Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Accessible Seats ({accessibleSeats})</span>
                    <span>₹{accessibleSeats * pricePerSeat}</span>
                  </div>
                  {companionSeats > 0 && (
                    <div className="flex justify-between">
                      <span>Companion Seats ({companionSeats})</span>
                      <span>₹{companionSeats * pricePerSeat}</span>
                    </div>
                  )}
                  <Separator className="my-2" />
                  <div className="flex justify-between font-medium">
                    <span>Total Amount</span>
                    <span>₹{totalPrice}</span>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={handleBooking}>
                Continue to Confirmation
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CheckCircle2 className="size-6 text-green-600" />
                Confirm Your Booking
              </DialogTitle>
              <DialogDescription>
                Please review your booking details before confirming
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="rounded-lg border p-4 space-y-4">
                <div>
                  <h4 className="mb-2">{venue.name}</h4>
                  <p className="text-sm text-muted-foreground">{venue.address}</p>
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-1">
                    <p className="text-muted-foreground">Date & Time</p>
                    <p className="font-medium">
                      {date && format(date, 'PPP')} at {time}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-muted-foreground">Total Seats</p>
                    <p className="font-medium">{totalSeats} seats</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-muted-foreground">Accessible Seats</p>
                    <p className="font-medium">{accessibleSeats}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-muted-foreground">Companion Seats</p>
                    <p className="font-medium">{companionSeats}</p>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Contact Details</p>
                  <div className="space-y-1 text-sm">
                    <p className="font-medium">{name}</p>
                    <p className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="size-3" />
                      {email}
                    </p>
                    <p className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="size-3" />
                      {phone}
                    </p>
                  </div>
                </div>

                {specialRequirements.length > 0 && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Special Requirements</p>
                      <div className="flex flex-wrap gap-2">
                        {specialRequirements.map((reqId) => {
                          const req = requirements.find(r => r.id === reqId);
                          return (
                            <Badge key={reqId} variant="secondary">
                              {req?.label}
                            </Badge>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}

                <Separator />

                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Amount</span>
                  <span className="text-2xl font-medium">₹{totalPrice}</span>
                </div>
              </div>

              <div className="rounded-lg bg-blue-50 dark:bg-blue-950 p-4 text-sm">
                <p className="text-blue-900 dark:text-blue-100">
                  📧 You will receive a booking confirmation email with your tickets and accessibility information.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleConfirmBooking}>
                Confirm & Pay ₹{totalPrice}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

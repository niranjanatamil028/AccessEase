import { useState } from 'react';
import { Venue } from '../types/venue';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { BookingModal } from './BookingModal';
import { 
  ArrowLeft, 
  MapPin, 
  Star, 
  Phone, 
  Calendar,
  Check,
  X,
  Accessibility,
  Users
} from 'lucide-react';

interface VenueDetailProps {
  venue: Venue;
  onBack: () => void;
}

export function VenueDetail({ venue, onBack }: VenueDetailProps) {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const availabilityPercentage = (venue.accessibleSeatsAvailable / venue.totalAccessibleSeats) * 100;
  
  const getAvailabilityStatus = () => {
    if (availabilityPercentage >= 50) return { text: 'Good Availability', color: 'text-green-600 bg-green-50' };
    if (availabilityPercentage >= 25) return { text: 'Limited Availability', color: 'text-yellow-600 bg-yellow-50' };
    return { text: 'Low Availability', color: 'text-red-600 bg-red-50' };
  };

  const status = getAvailabilityStatus();

  return (
    <div className="space-y-6">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="gap-2"
      >
        <ArrowLeft className="size-4" />
        Back to Venues
      </Button>

      <div className="relative h-[400px] rounded-lg overflow-hidden">
        <img 
          src={venue.image} 
          alt={venue.name}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-2">
            <h1>{venue.name}</h1>
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="size-4" />
                <span>{venue.address}</span>
              </div>
              {venue.distance && (
                <span>• {venue.distance} km away</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Star className="size-5 fill-yellow-400 stroke-yellow-400" />
            <span className="text-xl">{venue.accessibilityRating}</span>
            <span className="text-sm text-muted-foreground">Accessibility</span>
          </div>
        </div>

        <p className="text-muted-foreground">{venue.description}</p>
      </div>

      <Separator />

      <Card className={status.color}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Accessible Seat Availability</span>
            <Badge variant="outline" className="bg-white">
              {status.text}
            </Badge>
          </CardTitle>
          <CardDescription>
            Real-time availability of reserved accessible seating
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-8">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Accessibility className="size-5" />
                <span className="text-3xl font-medium">{venue.accessibleSeatsAvailable}</span>
                <span className="text-muted-foreground">/ {venue.totalAccessibleSeats}</span>
              </div>
              <p className="text-sm text-muted-foreground">Available accessible seats</p>
            </div>
            
            <Separator orientation="vertical" className="h-16" />
            
            <div className="flex-1">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Availability</span>
                  <span>{Math.round(availabilityPercentage)}%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-current transition-all"
                    style={{ width: `${availabilityPercentage}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex gap-3">
            <Button className="flex-1 gap-2" onClick={() => setBookingModalOpen(true)}>
              <Calendar className="size-4" />
              Book Accessible Seat
            </Button>
            <Button variant="outline" className="gap-2">
              <Phone className="size-4" />
              Call Venue
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Accessibility Features</CardTitle>
          <CardDescription>
            Available facilities and services for differently-abled visitors
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {venue.features.map(feature => (
              <div 
                key={feature.id}
                className="flex items-start gap-3 p-3 rounded-lg border bg-card"
              >
                <div className={`shrink-0 mt-0.5 ${feature.available ? 'text-green-600' : 'text-red-600'}`}>
                  {feature.available ? (
                    <Check className="size-5" />
                  ) : (
                    <X className="size-5" />
                  )}
                </div>
                <div className="space-y-1 flex-1">
                  <h4 className={feature.available ? '' : 'text-muted-foreground'}>
                    {feature.name}
                  </h4>
                  {feature.description && (
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Additional Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground">Category</span>
            <Badge>{venue.category.charAt(0).toUpperCase() + venue.category.slice(1)}</Badge>
          </div>
          <Separator />
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground">Overall Rating</span>
            <div className="flex items-center gap-1">
              <Star className="size-4 fill-yellow-400 stroke-yellow-400" />
              <span>{venue.rating}</span>
            </div>
          </div>
          <Separator />
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground">Service Animals</span>
            <span>
              {venue.features.find(f => f.id === 'service-animal')?.available ? (
                <Check className="size-5 text-green-600" />
              ) : (
                <X className="size-5 text-red-600" />
              )}
            </span>
          </div>
          <Separator />
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground">Companion Seating</span>
            <span>
              {venue.features.find(f => f.id === 'companion')?.available ? (
                <Check className="size-5 text-green-600" />
              ) : (
                <X className="size-5 text-red-600" />
              )}
            </span>
          </div>
        </CardContent>
      </Card>

      <BookingModal 
        open={bookingModalOpen} 
        onOpenChange={setBookingModalOpen}
        venue={venue}
      />
    </div>
  );
}
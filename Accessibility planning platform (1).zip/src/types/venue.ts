export interface AccessibilityFeature {
  id: string;
  name: string;
  available: boolean;
  description?: string;
}

export interface Venue {
  id: string;
  name: string;
  category: 'cinema' | 'restaurant' | 'museum' | 'theater' | 'stadium' | 'other';
  address: string;
  image: string;
  rating: number;
  accessibilityRating: number;
  accessibleSeatsAvailable: number;
  totalAccessibleSeats: number;
  features: AccessibilityFeature[];
  description: string;
  distance?: number;
}

export type FilterCategory = 'all' | 'cinema' | 'restaurant' | 'museum' | 'theater' | 'stadium';
